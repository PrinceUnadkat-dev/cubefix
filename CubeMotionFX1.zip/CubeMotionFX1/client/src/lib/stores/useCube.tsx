import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import * as THREE from "three";
import { CubeState, createInitialCubeState, checkIfSolved } from "../cube/CubeState";
import { Move, parseAlgorithm, getInverseMove } from "../cube/MoveNotation";
import { generateScramble, generateBasicSolution } from "../cube/CubeAlgorithms";

interface CubeStore {
  // State
  cubeState: CubeState;
  isAnimating: boolean;
  currentMove: Move | null;
  moveHistory: string[];
  animationQueue: Move[];
  isSolved: boolean;
  animationSpeed: number;
  
  // Actions
  initializeCube: () => void;
  scramble: () => void;
  solve: () => void;
  reset: () => void;
  executeMove: (notation: string) => void;
  executeAlgorithm: (algorithm: string) => void;
  undoLastMove: () => void;
  setAnimating: (animating: boolean) => void;
  updatePiecePosition: (pieceId: string, position: THREE.Vector3, rotation: THREE.Euler) => void;
  setAnimationSpeed: (speed: number) => void;
  
  // Queue management
  addToQueue: (moves: Move[]) => void;
  processQueue: () => void;
  clearQueue: () => void;
  addToHistory: (notation: string) => void;
}

// Removed AnimationQueue - using simple array-based queue instead

export const useCube = create<CubeStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    cubeState: createInitialCubeState(),
    isAnimating: false,
    currentMove: null,
    moveHistory: [],
    animationQueue: [],
    isSolved: true,
    animationSpeed: 1,

    // Initialize cube with proper queue setup
    initializeCube: () => {
      const cubeState = createInitialCubeState();
      
      // Reset all state
      set({ 
        cubeState, 
        isSolved: true, 
        moveHistory: [],
        animationQueue: [],
        currentMove: null,
        isAnimating: false
      });
    },

    // Scramble cube with collision prevention
    scramble: () => {
      const { isAnimating } = get();
      if (isAnimating) {
        console.log("Cannot scramble: animation in progress");
        return;
      }

      console.log("Scrambling cube...");
      
      // Generate optimized scramble sequence
      const scrambleMoves = generateScramble(20);
      const scrambleNotation = scrambleMoves.map(m => m.notation).join(' ');
      
      // Add to history
      get().addToHistory(`Scramble: ${scrambleNotation}`);
      
      // Add to queue with high priority
      get().addToQueue(scrambleMoves);
      
      set({ isSolved: false });
    },

    // Solve cube
    solve: () => {
      const { isAnimating, isSolved } = get();
      if (isAnimating) {
        console.log("Cannot solve: animation in progress");
        return;
      }
      
      if (isSolved) {
        console.log("Cube is already solved");
        return;
      }

      console.log("Solving cube...");
      
      const solution = generateBasicSolution();
      const solutionNotation = solution.map(m => m.notation).join(' ');
      
      get().addToHistory(`Solution: ${solutionNotation}`);
      get().addToQueue(solution);
    },

    // Reset cube to solved state
    reset: () => {
      console.log("Resetting cube...");
      
      const cubeState = createInitialCubeState();
      set({ 
        cubeState, 
        isSolved: true, 
        moveHistory: [],
        animationQueue: [],
        currentMove: null,
        isAnimating: false
      });
    },

    // Execute single move with validation
    executeMove: (notation: string) => {
      const { isAnimating } = get();
      if (isAnimating) {
        console.log(`Cannot execute move ${notation}: animation in progress`);
        return;
      }

      try {
        const moves = parseAlgorithm(notation);
        if (moves.length === 0) {
          console.warn(`No valid moves found in notation: ${notation}`);
          return;
        }

        console.log(`Executing move: ${notation}`);
        
        get().addToHistory(notation);
        get().addToQueue(moves);
        
        set({ isSolved: false });
      } catch (error) {
        console.error(`Invalid move notation: ${notation}`, error);
      }
    },

    // Execute algorithm with optimization
    executeAlgorithm: (algorithm: string) => {
      const { isAnimating } = get();
      if (isAnimating) {
        console.log(`Cannot execute algorithm: animation in progress`);
        return;
      }

      try {
        const moves = parseAlgorithm(algorithm);
        if (moves.length === 0) {
          console.warn(`No valid moves found in algorithm: ${algorithm}`);
          return;
        }

        console.log(`Executing algorithm: ${algorithm} (${moves.length} moves)`);
        
        get().addToHistory(algorithm);
        get().addToQueue(moves);
        
        set({ isSolved: false });
      } catch (error) {
        console.error(`Invalid algorithm: ${algorithm}`, error);
      }
    },

    // Undo last move
    undoLastMove: () => {
      const { isAnimating, moveHistory } = get();
      if (isAnimating || moveHistory.length === 0) return;

      const lastMove = moveHistory[moveHistory.length - 1];
      try {
        const moves = parseAlgorithm(lastMove);
        const inverseMoves = moves.reverse().map(getInverseMove);
        
        console.log(`Undoing: ${lastMove}`);
        
        get().addToQueue(inverseMoves);
        
        set(state => ({
          moveHistory: state.moveHistory.slice(0, -1)
        }));
      } catch (error) {
        console.error(`Cannot undo move: ${lastMove}`, error);
      }
    },

    // Set animation state with queue processing
    setAnimating: (animating: boolean) => {
      console.log(`Animation state changed: ${animating}`);
      set({ isAnimating: animating });
      
      if (!animating) {
        // Process next move in queue after a short delay
        setTimeout(() => {
          if (!get().isAnimating) {
            get().processQueue();
          }
        }, 50);
      }
    },

    // Update piece position (called by animation system)
    updatePiecePosition: (pieceId: string, position: THREE.Vector3, rotation: THREE.Euler) => {
      set(state => {
        const piece = state.cubeState.pieces[pieceId];
        if (!piece) return state;

        return {
          cubeState: {
            ...state.cubeState,
            pieces: {
              ...state.cubeState.pieces,
              [pieceId]: {
                ...piece,
                position: position.clone(),
                rotation: rotation.clone()
              }
            }
          }
        };
      });
    },

    // Set animation speed
    setAnimationSpeed: (speed: number) => {
      const clampedSpeed = Math.max(0.1, Math.min(3.0, speed));
      console.log(`Animation speed set to: ${clampedSpeed}x`);
      set({ animationSpeed: clampedSpeed });
    },

    // Add moves to animation queue with collision detection
    addToQueue: (moves: Move[]) => {
      if (moves.length === 0) return;

      console.log(`Adding ${moves.length} moves to queue:`, moves.map(m => m.notation).join(' '));
      
      // Simple queue - add moves one by one without complex optimization
      moves.forEach(move => {
        set(state => ({
          animationQueue: [...state.animationQueue, move]
        }));
      });
      
      // Start processing if not already animating
      if (!get().isAnimating) {
        get().processQueue();
      }
    },

    // Process animation queue
    processQueue: () => {
      const { isAnimating, animationQueue: queue } = get();
      
      if (isAnimating) {
        console.log("Cannot process queue: animation in progress");
        return;
      }

      if (queue.length === 0) {
        console.log("Queue is empty, nothing to process");
        return;
      }

      console.log(`Processing queue (${queue.length} moves remaining)`);
      
      // Get next move and remove from queue
      const nextMove = queue[0];
      const remainingMoves = queue.slice(1);
      
      set({ 
        animationQueue: remainingMoves,
        currentMove: nextMove,
        isAnimating: true
      });
      
      console.log(`Processing move: ${nextMove.notation}`);
    },

    // Clear animation queue
    clearQueue: () => {
      console.log("Clearing animation queue");
      set({ 
        animationQueue: [], 
        currentMove: null,
        isAnimating: false
      });
    },

    // Add to move history with limit
    addToHistory: (notation: string) => {
      set(state => ({
        moveHistory: [...state.moveHistory.slice(-49), notation] // Keep last 50 moves
      }));
    }
  }))
);

// Subscribe to cube state changes to check if solved (disabled for now to prevent false positives)
/*
useCube.subscribe(
  (state) => state.cubeState,
  (cubeState) => {
    const solved = checkIfSolved(cubeState);
    const currentlySolved = useCube.getState().isSolved;
    
    if (solved !== currentlySolved) {
      useCube.setState({ isSolved: solved });
      if (solved) {
        console.log("🎉 Cube solved!");
        // Clear any remaining moves in queue when solved
        useCube.getState().clearQueue();
      }
    }
  }
);
*/

// Subscribe to animation queue changes for debugging
useCube.subscribe(
  (state) => state.animationQueue,
  (queue) => {
    if (queue.length > 0) {
      console.log(`Queue updated: ${queue.length} moves pending`);
    }
  }
);

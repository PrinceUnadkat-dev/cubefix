import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

// Standard Rubik's cube colors
export const CUBE_COLORS = {
  white: '#FFFFFF',
  yellow: '#FFFF00', 
  red: '#CC0000',
  orange: '#FF6900',
  green: '#009E4F',
  blue: '#0052CC',
  black: '#000000'
} as const;

export type CubeColor = keyof typeof CUBE_COLORS;

// Color counts for a standard 3x3 cube (9 stickers per face)
const MAX_COLOR_COUNT = 9;

interface ColorManagerStore {
  // State
  selectedColor: CubeColor;
  colorCounts: Record<CubeColor, number>;
  isColoringMode: boolean;
  filledStickers: Record<string, CubeColor>; // pieceId-face -> color
  
  // Actions
  setSelectedColor: (color: CubeColor) => void;
  setColoringMode: (enabled: boolean) => void;
  fillSticker: (pieceId: string, face: string, color: CubeColor) => boolean;
  clearSticker: (pieceId: string, face: string) => void;
  resetColors: () => void;
  resetToSolved: () => void;
  canUseColor: (color: CubeColor) => boolean;
  getColorCount: (color: CubeColor) => number;
  getRemainingCount: (color: CubeColor) => number;
}

// Default solved state colors for center pieces
const CENTER_COLORS: Record<string, CubeColor> = {
  'front': 'green',   // Front face center is always green
  'back': 'blue',     // Back face center is always blue  
  'right': 'red',     // Right face center is always red
  'left': 'orange',   // Left face center is always orange
  'up': 'white',      // Top face center is always white
  'down': 'yellow'    // Bottom face center is always yellow
};

export const useColorManager = create<ColorManagerStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    selectedColor: 'white',
    colorCounts: {
      white: 0,
      yellow: 0,
      red: 0,
      orange: 0,
      green: 0,
      blue: 0,
      black: 0
    },
    isColoringMode: false,
    filledStickers: {},

    // Set selected color for painting
    setSelectedColor: (color: CubeColor) => {
      console.log(`Selected color: ${color}`);
      set({ selectedColor: color });
    },

    // Toggle coloring mode
    setColoringMode: (enabled: boolean) => {
      console.log(`Coloring mode: ${enabled ? 'enabled' : 'disabled'}`);
      set({ isColoringMode: enabled });
    },

    // Fill a sticker with selected color
    fillSticker: (pieceId: string, face: string, color: CubeColor) => {
      const { colorCounts, filledStickers } = get();
      const stickerId = `${pieceId}-${face}`;
      
      // Check if color is available
      if (colorCounts[color] >= MAX_COLOR_COUNT) {
        console.warn(`Cannot use color ${color}: maximum count (${MAX_COLOR_COUNT}) reached`);
        return false;
      }

      // Remove previous color if exists
      const previousColor = filledStickers[stickerId];
      const newColorCounts = { ...colorCounts };
      
      if (previousColor) {
        newColorCounts[previousColor] = Math.max(0, newColorCounts[previousColor] - 1);
      }
      
      // Add new color
      newColorCounts[color] = newColorCounts[color] + 1;
      
      const newFilledStickers = {
        ...filledStickers,
        [stickerId]: color
      };

      console.log(`Filled sticker ${stickerId} with ${color}. Count: ${newColorCounts[color]}/${MAX_COLOR_COUNT}`);
      
      set({
        colorCounts: newColorCounts,
        filledStickers: newFilledStickers
      });
      
      return true;
    },

    // Clear a sticker
    clearSticker: (pieceId: string, face: string) => {
      const { colorCounts, filledStickers } = get();
      const stickerId = `${pieceId}-${face}`;
      const color = filledStickers[stickerId];
      
      if (!color) return;
      
      const newColorCounts = { ...colorCounts };
      newColorCounts[color] = Math.max(0, newColorCounts[color] - 1);
      
      const newFilledStickers = { ...filledStickers };
      delete newFilledStickers[stickerId];
      
      console.log(`Cleared sticker ${stickerId}. ${color} count: ${newColorCounts[color]}/${MAX_COLOR_COUNT}`);
      
      set({
        colorCounts: newColorCounts,
        filledStickers: newFilledStickers
      });
    },

    // Reset all colors
    resetColors: () => {
      console.log('Resetting all colors');
      set({
        colorCounts: {
          white: 0,
          yellow: 0,
          red: 0,
          orange: 0,
          green: 0,
          blue: 0,
          black: 0
        },
        filledStickers: {},
        isColoringMode: false
      });
    },

    // Reset to standard solved cube colors
    resetToSolved: () => {
      console.log('Resetting to solved cube colors');
      
      const solvedStickers: Record<string, CubeColor> = {};
      const solvedCounts = {
        white: 9,
        yellow: 9,
        red: 9,
        orange: 9,
        green: 9,
        blue: 9,
        black: 0
      };

      // Fill all stickers with solved state colors
      for (let x = 0; x < 3; x++) {
        for (let y = 0; y < 3; y++) {
          for (let z = 0; z < 3; z++) {
            if (x === 1 && y === 1 && z === 1) continue; // Skip center
            
            const pieceId = `${x}-${y}-${z}`;
            
            // Assign colors based on position
            if (x === 2) solvedStickers[`${pieceId}-right`] = 'red';
            if (x === 0) solvedStickers[`${pieceId}-left`] = 'orange';
            if (y === 2) solvedStickers[`${pieceId}-up`] = 'white';
            if (y === 0) solvedStickers[`${pieceId}-down`] = 'yellow';
            if (z === 2) solvedStickers[`${pieceId}-front`] = 'green';
            if (z === 0) solvedStickers[`${pieceId}-back`] = 'blue';
          }
        }
      }

      set({
        colorCounts: solvedCounts,
        filledStickers: solvedStickers,
        isColoringMode: false
      });
    },

    // Check if color can be used (not at max count)
    canUseColor: (color: CubeColor) => {
      const { colorCounts } = get();
      return colorCounts[color] < MAX_COLOR_COUNT;
    },

    // Get current count for a color
    getColorCount: (color: CubeColor) => {
      const { colorCounts } = get();
      return colorCounts[color];
    },

    // Get remaining available count for a color
    getRemainingCount: (color: CubeColor) => {
      const { colorCounts } = get();
      return MAX_COLOR_COUNT - colorCounts[color];
    }
  }))
);

// Get center color for a face
export function getCenterColor(face: string): CubeColor {
  return CENTER_COLORS[face] || 'white';
}

// Subscribe to color changes for debugging
useColorManager.subscribe(
  (state) => state.colorCounts,
  (colorCounts) => {
    const totalStickers = Object.values(colorCounts).reduce((sum, count) => sum + count, 0);
    console.log(`Color counts updated. Total stickers: ${totalStickers}/54`);
  }
);
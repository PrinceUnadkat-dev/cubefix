export interface Move {
  face: string;
  direction: number; // 1 for clockwise, -1 for counter-clockwise
  amount: number; // 1 for 90°, 2 for 180°
  notation: string; // Original notation string
}

export function parseMove(notation: string): Move {
  const trimmed = notation.trim().toUpperCase();
  
  if (!trimmed) {
    throw new Error('Empty move notation');
  }

  const face = trimmed[0];
  const modifiers = trimmed.slice(1);

  // Validate face
  if (!'FBLRUD'.includes(face)) {
    throw new Error(`Invalid face: ${face}`);
  }

  let direction = 1; // Default clockwise
  let amount = 1; // Default 90 degrees

  // Parse modifiers
  if (modifiers.includes('\'') || modifiers.includes('I')) {
    direction = -1; // Counter-clockwise
  }
  
  if (modifiers.includes('2')) {
    amount = 2; // 180 degrees
  }

  return {
    face,
    direction,
    amount,
    notation: trimmed
  };
}

export function parseAlgorithm(algorithm: string): Move[] {
  if (!algorithm.trim()) {
    return [];
  }

  return algorithm
    .trim()
    .split(/\s+/)
    .filter(move => move.length > 0)
    .map(parseMove);
}

export function getInverseMove(move: Move): Move {
  let newDirection = -move.direction;
  let newNotation = move.face;

  if (move.amount === 2) {
    // 180-degree moves are their own inverse
    newDirection = move.direction;
    newNotation += '2';
  } else if (newDirection === -1) {
    newNotation += '\'';
  }

  return {
    face: move.face,
    direction: newDirection,
    amount: move.amount,
    notation: newNotation
  };
}

export function simplifyAlgorithm(moves: Move[]): Move[] {
  const simplified: Move[] = [];
  
  for (const move of moves) {
    if (simplified.length === 0) {
      simplified.push(move);
      continue;
    }

    const lastMove = simplified[simplified.length - 1];
    
    // Check if we can combine with the last move
    if (lastMove.face === move.face) {
      const totalAmount = lastMove.direction * lastMove.amount + move.direction * move.amount;
      
      if (totalAmount === 0) {
        // Moves cancel out
        simplified.pop();
      } else {
        // Update the last move
        const normalizedAmount = ((totalAmount % 4) + 4) % 4;
        if (normalizedAmount === 0) {
          simplified.pop();
        } else {
          const newDirection = normalizedAmount > 2 ? -1 : 1;
          const newAmount = normalizedAmount > 2 ? 4 - normalizedAmount : normalizedAmount;
          
          let newNotation = move.face;
          if (newAmount === 2) {
            newNotation += '2';
          } else if (newDirection === -1) {
            newNotation += '\'';
          }

          simplified[simplified.length - 1] = {
            face: move.face,
            direction: newDirection,
            amount: newAmount,
            notation: newNotation
          };
        }
      }
    } else {
      simplified.push(move);
    }
  }

  return simplified;
}

// Common algorithms
export const COMMON_ALGORITHMS = {
  'Sexy Move': "R U R' U'",
  'Reverse Sexy Move': "U R U' R'",
  'Right Hand': "R U R' U R U2 R'", // Sune
  'Left Hand': "L' U' L U' L' U2 L", // Anti-Sune
  'T-Perm': "R U R' F' R U R' U' R' F R2 U' R'",
  'J-Perm': "R U R' F' R U R' U' R' F R2 U' R'",
  'Y-Perm': "F R U' R' U' R U R' F' R U R' U' R' F R F'",
  'H-Perm': "M2 U M2 U2 M2 U M2",
  'Z-Perm': "M2 U M2 U M' U2 M2 U2 M' U2"
};

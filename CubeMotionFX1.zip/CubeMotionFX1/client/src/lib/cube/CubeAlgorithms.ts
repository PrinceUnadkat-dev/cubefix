import { Move, parseAlgorithm } from "./MoveNotation";

// CFOP Method Algorithms
export const CFOP_ALGORITHMS = {
  // Cross algorithms (usually intuitive)
  cross: {
    'White Cross': [] // Typically solved intuitively
  },

  // F2L (First Two Layers) - Basic cases
  f2l: {
    'Basic Case 1': "R U' R'",
    'Basic Case 2': "F' U F",
    'Basic Case 3': "R U R' U' R U R'",
    'Basic Case 4': "R U2 R' U' R U R'",
    'Corner in place, edge in top': "R U' R' d R' U R",
    'Edge in place, corner in top': "U R U' R' U F' U F"
  },

  // OLL (Orientation of Last Layer) - Two-Look OLL
  oll: {
    // Cross cases
    'Dot': "F R U R' U' F' f R U R' U' f'",
    'L Shape': "f R U R' U' f'",
    'Line': "F R U R' U' F'",
    
    // Corner orientation cases  
    'Sune': "R U R' U R U2 R'",
    'Anti-Sune': "R U2 R' U' R U' R'",
    'H': "F R U R' U' F' f R U R' U' f'",
    'Pi': "R U2 R2 U' R2 U' R2 U2 R",
    'T': "r U R' U' r' F R F'",
    'L': "F R' F' r U R U' r'",
    'U': "R U R' U R U' R' U' R' F R F'"
  },

  // PLL (Permutation of Last Layer) - Two-Look PLL
  pll: {
    // Corner permutation
    'A-Perm': "R' F R' B2 R F' R' B2 R2",
    'E-Perm': "R B' R F2 R' B R F2 R2",
    
    // Edge permutation
    'H-Perm': "M2 U M2 U2 M2 U M2",
    'Z-Perm': "M2 U M2 U M' U2 M2 U2 M' U2",
    'Ua-Perm': "M2 U M U2 M' U M2",
    'Ub-Perm': "M2 U' M U2 M' U' M2",
    
    // Full PLL
    'T-Perm': "R U R' F' R U R' U' R' F R2 U' R'",
    'J-Perm': "R U R' F' R U R' U' R' F R2 U' R'",
    'R-Perm': "R U R' F' R U2 R' U2 R' F R U R U2 R'",
    'V-Perm': "R' U R' U' y R' F' R2 U' R' U R' F R F",
    'Y-Perm': "F R U' R' U' R U R' F' R U R' U' R' F R F'",
    'N-Perm': "R U R' U R U R' F' R U R' U' R' F R2 U' R' U2 R U' R'",
    'G-Perm': "R2 U R' U R' U' R U' R2 D U' R' U R D'"
  }
};

// Beginner Method Algorithms
export const BEGINNER_ALGORITHMS = {
  // White cross (usually intuitive)
  whiteCross: {},

  // White corners
  whiteCorners: {
    'Corner in wrong position': "R' D' R D",
    'Corner needs to be flipped': "R' D' R D R' D' R D",
  },

  // Second layer edges
  secondLayer: {
    'Right edge': "U R U' R' U' F' U F",
    'Left edge': "U' L' U L U F U' F'",
  },

  // Yellow cross
  yellowCross: {
    'Dot to L': "F R U R' U' F'",
    'L to Line': "F R U R' U' F'",
    'Line to Cross': "F R U R' U' F'"
  },

  // Yellow corners orientation
  yellowCorners: {
    'Orient corners': "R' D' R D"
  },

  // Yellow corners permutation
  yellowCornersPermutation: {
    'Permute corners': "R' F R' B2 R F' R' B2 R2"
  },

  // Yellow edges permutation
  yellowEdgesPermutation: {
    'Permute edges clockwise': "R U R' F' R U R' U' R' F R2 U' R'",
    'Permute edges counter-clockwise': "R U2 R' F' R U R' U' R' F R U' R'"
  }
};

// Generate varied scramble sequences with proper constraints
export function generateScramble(length: number = 20): Move[] {
  const faces = ['F', 'B', 'R', 'L', 'U', 'D'];
  const modifiers = ['', '\'', '2'];
  const moves: Move[] = [];
  const recentMoves: string[] = [];

  for (let i = 0; i < length; i++) {
    let face: string;
    let attempts = 0;
    
    // Ensure no consecutive moves on same face or opposite faces
    do {
      face = faces[Math.floor(Math.random() * faces.length)];
      attempts++;
      
      // Prevent infinite loops
      if (attempts > 20) {
        face = faces.find(f => !isConflictingFace(f, recentMoves)) || face;
        break;
      }
    } while (isConflictingFace(face, recentMoves));

    // Add variety to modifiers - avoid too many of the same type
    const availableModifiers = modifiers.filter(mod => {
      if (recentMoves.length < 2) return true;
      const lastTwoModifiers = recentMoves.slice(-2).map(m => m.slice(1));
      return !(lastTwoModifiers.every(m => m === mod && mod !== ''));
    });
    
    const modifier = availableModifiers.length > 0 
      ? availableModifiers[Math.floor(Math.random() * availableModifiers.length)]
      : modifiers[Math.floor(Math.random() * modifiers.length)];
    
    const move = face + modifier;
    recentMoves.push(move);
    
    // Keep only last 3 moves for conflict checking
    if (recentMoves.length > 3) {
      recentMoves.shift();
    }

    moves.push(...parseAlgorithm(move));
  }

  console.log('Generated scramble:', moves.map(m => m.notation).join(' '));
  return moves;
}

// Check if a face conflicts with recent moves
function isConflictingFace(face: string, recentMoves: string[]): boolean {
  if (recentMoves.length === 0) return false;
  
  const oppositeFaces: Record<string, string> = {
    'F': 'B', 'B': 'F',
    'R': 'L', 'L': 'R', 
    'U': 'D', 'D': 'U'
  };
  
  const lastMove = recentMoves[recentMoves.length - 1];
  const lastFace = lastMove[0];
  
  // Don't repeat same face consecutively
  if (face === lastFace) return true;
  
  // Don't alternate between opposite faces too much
  if (recentMoves.length >= 2) {
    const secondLastMove = recentMoves[recentMoves.length - 2];
    const secondLastFace = secondLastMove[0];
    
    if (face === secondLastFace && oppositeFaces[face] === lastFace) {
      return true;
    }
  }
  
  return false;
}

// Basic solve attempt (not a real solver, just demonstration)
export function generateBasicSolution(): Move[] {
  // This is a placeholder - a real solver would analyze the cube state
  // For now, return some basic algorithms
  const solution = [
    ...parseAlgorithm("F R U R' U' F'"), // Yellow cross
    ...parseAlgorithm("R U R' U R U2 R'"), // Sune
    ...parseAlgorithm("R U R' F' R U R' U' R' F R2 U' R'"), // T-perm
  ];
  
  return solution;
}

// Get algorithm by name
export function getAlgorithm(category: string, name: string): Move[] {
  const algorithms = { ...CFOP_ALGORITHMS, ...BEGINNER_ALGORITHMS } as any;
  
  if (algorithms[category] && algorithms[category][name]) {
    return parseAlgorithm(algorithms[category][name]);
  }
  
  return [];
}

// Get all algorithms in a category
export function getAlgorithmCategory(category: string): Record<string, string> {
  const algorithms = { ...CFOP_ALGORITHMS, ...BEGINNER_ALGORITHMS } as any;
  return algorithms[category] || {};
}

import * as THREE from "three";

export interface PieceState {
  id: string;
  position: THREE.Vector3;
  rotation: THREE.Euler;
  colors: Record<string, string>;
  originalPosition: THREE.Vector3;
}

export interface CubeState {
  pieces: Record<string, PieceState>;
  isSolved: boolean;
  moveCount: number;
}

// Standard Rubik's cube face colors
export const FACE_COLORS = {
  front: '#009E4F',   // Green
  back: '#0052CC',    // Blue  
  right: '#FF6900',   // Orange
  left: '#CC0000',    // Red
  up: '#FFFF00',      // Yellow
  down: '#FFFFFF'     // White
};

export function createInitialCubeState(): CubeState {
  const pieces: Record<string, PieceState> = {};

  // Generate all 26 pieces (27 total minus center)
  for (let x = 0; x < 3; x++) {
    for (let y = 0; y < 3; y++) {
      for (let z = 0; z < 3; z++) {
        // Skip center piece
        if (x === 1 && y === 1 && z === 1) continue;

        const pieceId = `${x}-${y}-${z}`;
        const position = new THREE.Vector3(
          (x - 1) * 1.0,
          (y - 1) * 1.0,
          (z - 1) * 1.0
        );

        const colors = getPieceColors(x, y, z);

        pieces[pieceId] = {
          id: pieceId,
          position: position.clone(),
          rotation: new THREE.Euler(0, 0, 0),
          colors,
          originalPosition: position.clone()
        };
      }
    }
  }

  return {
    pieces,
    isSolved: true,
    moveCount: 0
  };
}

function getPieceColors(x: number, y: number, z: number): Record<string, string> {
  const colors: Record<string, string> = {};

  // Assign colors based on position
  if (z === 2) colors.front = FACE_COLORS.front;   // Front face
  if (z === 0) colors.back = FACE_COLORS.back;     // Back face
  if (x === 2) colors.right = FACE_COLORS.right;   // Right face
  if (x === 0) colors.left = FACE_COLORS.left;     // Left face
  if (y === 2) colors.up = FACE_COLORS.up;         // Up face
  if (y === 0) colors.down = FACE_COLORS.down;     // Down face

  return colors;
}

export function checkIfSolved(cubeState: CubeState): boolean {
  // Check if all pieces are in their original positions
  // This is a simplified check - in reality, we'd need to check color orientations
  return Object.values(cubeState.pieces).every(piece => {
    const distance = piece.position.distanceTo(piece.originalPosition);
    return distance < 0.1; // Small tolerance for floating point errors
  });
}

export function scrambleCube(cubeState: CubeState, moves: number = 20): string[] {
  const faces = ['F', 'B', 'R', 'L', 'U', 'D'];
  const modifiers = ['', '\'', '2'];
  const scrambleMoves: string[] = [];

  for (let i = 0; i < moves; i++) {
    const face = faces[Math.floor(Math.random() * faces.length)];
    const modifier = modifiers[Math.floor(Math.random() * modifiers.length)];
    const move = face + modifier;
    scrambleMoves.push(move);
  }

  return scrambleMoves;
}

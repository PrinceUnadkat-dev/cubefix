import { Move } from "./MoveNotation";

export interface QueuedMove {
  move: Move;
  timestamp: number;
  priority: number;
  id: string;
}

export class AnimationQueue {
  private queue: QueuedMove[] = [];
  private isProcessing = false;
  private processingId: string | null = null;
  private callbacks: {
    onProcess?: (move: Move) => void;
    onComplete?: () => void;
    onError?: (error: string) => void;
    onQueueUpdate?: (queue: QueuedMove[]) => void;
  } = {};

  constructor() {}

  // Add move to queue with collision detection
  addMove(move: Move, priority: number = 0): string {
    // Generate unique ID for this move
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const queuedMove: QueuedMove = {
      move,
      timestamp: Date.now(),
      priority,
      id
    };

    // Check for conflicting moves (same face)
    const conflictingIndex = this.queue.findIndex(item => 
      item.move.face.toLowerCase() === move.face.toLowerCase() && 
      item.priority <= priority
    );

    if (conflictingIndex !== -1) {
      // Replace conflicting move if new one has higher or equal priority
      console.log(`Replacing conflicting move: ${this.queue[conflictingIndex].move.notation} with ${move.notation}`);
      this.queue.splice(conflictingIndex, 1);
    }

    // Insert based on priority (higher priority first)
    let insertIndex = this.queue.findIndex(item => item.priority < priority);
    if (insertIndex === -1) {
      insertIndex = this.queue.length;
    }

    this.queue.splice(insertIndex, 0, queuedMove);
    this.callbacks.onQueueUpdate?.(this.queue.slice());
    
    return id;
  }

  // Add multiple moves with optimization
  addMoves(moves: Move[], priority: number = 0): string[] {
    const ids: string[] = [];
    
    // Optimize sequence to prevent redundant moves
    const optimizedMoves = this.optimizeMoveSequence(moves);
    
    optimizedMoves.forEach(move => {
      const id = this.addMove(move, priority);
      ids.push(id);
    });

    return ids;
  }

  // Optimize move sequence to prevent overlapping animations
  private optimizeMoveSequence(moves: Move[]): Move[] {
    const optimized: Move[] = [];
    
    for (const move of moves) {
      // Check if this move conflicts with the last move
      if (optimized.length > 0) {
        const lastMove = optimized[optimized.length - 1];
        
        // If same face, combine moves
        if (lastMove.face.toLowerCase() === move.face.toLowerCase()) {
          const combinedDirection = lastMove.direction * lastMove.amount + move.direction * move.amount;
          
          if (combinedDirection === 0) {
            // Moves cancel out
            optimized.pop();
            continue;
          } else {
            // Update the last move
            const normalizedAmount = ((combinedDirection % 4) + 4) % 4;
            if (normalizedAmount === 0) {
              optimized.pop();
              continue;
            }
            
            const newDirection = normalizedAmount > 2 ? -1 : 1;
            const newAmount = normalizedAmount > 2 ? 4 - normalizedAmount : normalizedAmount;
            
            let newNotation = move.face;
            if (newAmount === 2) {
              newNotation += '2';
            } else if (newDirection === -1) {
              newNotation += '\'';
            }

            optimized[optimized.length - 1] = {
              face: move.face,
              direction: newDirection,
              amount: newAmount,
              notation: newNotation
            };
            continue;
          }
        }
      }
      
      optimized.push(move);
    }
    
    return optimized;
  }

  // Get next move without removing it
  peek(): QueuedMove | null {
    return this.queue.length > 0 ? this.queue[0] : null;
  }

  // Remove and return next move
  dequeue(): QueuedMove | null {
    const move = this.queue.shift() || null;
    this.callbacks.onQueueUpdate?.(this.queue.slice());
    return move;
  }

  // Remove specific move by ID
  removeMove(id: string): boolean {
    const index = this.queue.findIndex(item => item.id === id);
    if (index !== -1) {
      this.queue.splice(index, 1);
      this.callbacks.onQueueUpdate?.(this.queue.slice());
      return true;
    }
    return false;
  }

  // Clear all moves
  clear(): void {
    const wasProcessing = this.isProcessing;
    this.queue = [];
    this.isProcessing = false;
    this.processingId = null;
    
    this.callbacks.onQueueUpdate?.(this.queue.slice());
    
    if (wasProcessing) {
      this.callbacks.onComplete?.();
    }
  }

  // Get queue length
  length(): number {
    return this.queue.length;
  }

  // Check if queue is empty
  isEmpty(): boolean {
    return this.queue.length === 0;
  }

  // Set processing state
  setProcessing(processing: boolean, moveId?: string): void {
    this.isProcessing = processing;
    this.processingId = processing ? (moveId || null) : null;
    
    if (!processing && this.isEmpty()) {
      this.callbacks.onComplete?.();
    }
  }

  // Check if currently processing
  isCurrentlyProcessing(): boolean {
    return this.isProcessing;
  }

  // Get currently processing move ID
  getCurrentlyProcessingId(): string | null {
    return this.processingId;
  }

  // Set callbacks
  setCallbacks(callbacks: {
    onProcess?: (move: Move) => void;
    onComplete?: () => void;
    onError?: (error: string) => void;
    onQueueUpdate?: (queue: QueuedMove[]) => void;
  }): void {
    this.callbacks = callbacks;
  }

  // Process next move in queue with collision prevention
  processNext(): boolean {
    if (this.isProcessing || this.isEmpty()) {
      return false;
    }

    const queuedMove = this.dequeue();
    if (!queuedMove) {
      return false;
    }

    console.log(`Processing move: ${queuedMove.move.notation} (ID: ${queuedMove.id})`);
    
    this.setProcessing(true, queuedMove.id);

    try {
      this.callbacks.onProcess?.(queuedMove.move);
      return true;
    } catch (error) {
      this.callbacks.onError?.(`Error processing move: ${error}`);
      this.setProcessing(false);
      return false;
    }
  }

  // Mark current processing as complete
  completeProcessing(): void {
    const wasProcessing = this.isProcessing;
    this.setProcessing(false);
    
    if (wasProcessing) {
      console.log(`Completed processing move ID: ${this.processingId}`);
    }
  }

  // Get all moves in queue
  getAllMoves(): Move[] {
    return this.queue.map(item => item.move);
  }

  // Get queue with IDs
  getQueueWithIds(): QueuedMove[] {
    return this.queue.slice();
  }

  // Get queue statistics
  getStats(): {
    total: number;
    processing: boolean;
    processingId: string | null;
    oldestTimestamp: number | null;
    newestTimestamp: number | null;
    averageWaitTime: number;
  } {
    const timestamps = this.queue.map(item => item.timestamp);
    const now = Date.now();
    const averageWaitTime = timestamps.length > 0 
      ? timestamps.reduce((sum, timestamp) => sum + (now - timestamp), 0) / timestamps.length
      : 0;
    
    return {
      total: this.queue.length,
      processing: this.isProcessing,
      processingId: this.processingId,
      oldestTimestamp: timestamps.length > 0 ? Math.min(...timestamps) : null,
      newestTimestamp: timestamps.length > 0 ? Math.max(...timestamps) : null,
      averageWaitTime
    };
  }

  // Remove moves older than specified time
  removeOldMoves(maxAge: number): number {
    const cutoff = Date.now() - maxAge;
    const originalLength = this.queue.length;
    
    this.queue = this.queue.filter(item => item.timestamp > cutoff);
    this.callbacks.onQueueUpdate?.(this.queue.slice());
    
    return originalLength - this.queue.length;
  }

  // Check for potential conflicts before adding moves
  hasConflicts(newMoves: Move[]): boolean {
    for (const newMove of newMoves) {
      for (const queuedMove of this.queue) {
        if (queuedMove.move.face.toLowerCase() === newMove.face.toLowerCase()) {
          return true;
        }
      }
    }
    return false;
  }

  // Priority constants
  static readonly PRIORITY = {
    LOW: 0,
    NORMAL: 1,
    HIGH: 2,
    URGENT: 3,
    IMMEDIATE: 4
  };
}

import { useKeyboardControls } from "@react-three/drei";
import { useEffect } from "react";
import { useCube } from "../lib/stores/useCube";

export function useCubeControls() {
  const [subscribe, getState] = useKeyboardControls();
  const { executeMove, scramble, solve, reset, isAnimating } = useCube();

  useEffect(() => {
    // Subscribe to all control keys
    const unsubscribeFns: (() => void)[] = [];

    // Face moves
    unsubscribeFns.push(
      subscribe((state) => state.frontClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("F");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.frontCounterClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("F'");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.rightClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("R");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.rightCounterClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("R'");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.upClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("U");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.upCounterClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("U'");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.leftClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("L");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.leftCounterClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("L'");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.downClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("D");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.downCounterClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("D'");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.backClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("B");
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.backCounterClockwise, (pressed) => {
        if (pressed && !isAnimating) {
          executeMove("B'");
        }
      })
    );

    // Action keys
    unsubscribeFns.push(
      subscribe((state) => state.scramble, (pressed) => {
        if (pressed && !isAnimating) {
          scramble();
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.solve, (pressed) => {
        if (pressed && !isAnimating) {
          solve();
        }
      })
    );

    unsubscribeFns.push(
      subscribe((state) => state.reset, (pressed) => {
        if (pressed) {
          reset();
        }
      })
    );

    // Cleanup function
    return () => {
      unsubscribeFns.forEach(fn => fn());
    };
  }, [subscribe, executeMove, scramble, solve, reset, isAnimating]);

  // Log controls for debugging
  useEffect(() => {
    const logControls = () => {
      const controls = getState();
      const activeControls = Object.entries(controls)
        .filter(([, pressed]) => pressed)
        .map(([key]) => key);
      
      if (activeControls.length > 0) {
        console.log("Active controls:", activeControls);
      }
    };

    const interval = setInterval(logControls, 1000);
    return () => clearInterval(interval);
  }, [getState]);
}

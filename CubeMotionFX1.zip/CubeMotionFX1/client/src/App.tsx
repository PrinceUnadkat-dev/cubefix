import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import { useCube } from "./lib/stores/useCube";
import { useIsMobile } from "./hooks/use-is-mobile";
import CubeScene from "./components/cube/CubeScene";
import SolverInterface from "./components/ui/SolverInterface";
import MobileControls from "./components/ui/MobileControls";
import "@fontsource/inter";

// Define control keys for cube manipulation
const controls = [
  { name: "rotateX", keys: ["KeyX"] },
  { name: "rotateY", keys: ["KeyY"] },
  { name: "rotateZ", keys: ["KeyZ"] },
  { name: "frontClockwise", keys: ["KeyF"] },
  { name: "frontCounterClockwise", keys: ["ShiftLeft", "KeyF"] },
  { name: "rightClockwise", keys: ["KeyR"] },
  { name: "rightCounterClockwise", keys: ["ShiftLeft", "KeyR"] },
  { name: "upClockwise", keys: ["KeyU"] },
  { name: "upCounterClockwise", keys: ["ShiftLeft", "KeyU"] },
  { name: "leftClockwise", keys: ["KeyL"] },
  { name: "leftCounterClockwise", keys: ["ShiftLeft", "KeyL"] },
  { name: "downClockwise", keys: ["KeyD"] },
  { name: "downCounterClockwise", keys: ["ShiftLeft", "KeyD"] },
  { name: "backClockwise", keys: ["KeyB"] },
  { name: "backCounterClockwise", keys: ["ShiftLeft", "KeyB"] },
  { name: "scramble", keys: ["Space"] },
  { name: "solve", keys: ["Enter"] },
  { name: "reset", keys: ["Escape"] },
];

function App() {
  const [showCanvas, setShowCanvas] = useState(false);
  const { initializeCube } = useCube();
  const isMobile = useIsMobile();

  // Initialize cube and show canvas
  useEffect(() => {
    initializeCube();
    setShowCanvas(true);
  }, [initializeCube]);

  if (!showCanvas) {
    return (
      <div style={{ 
        width: '100vw', 
        height: '100vh', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)'
      }}>
        <div style={{ color: 'white', fontSize: '1.5rem' }}>Loading Cube...</div>
      </div>
    );
  }

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      position: 'relative', 
      overflow: 'hidden',
      background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)'
    }}>
      <KeyboardControls map={controls}>
        <Canvas
          shadows
          camera={{
            position: [5, 5, 8],
            fov: 50,
            near: 0.1,
            far: 1000
          }}
          gl={{
            antialias: true,
            powerPreference: "high-performance"
          }}
          style={{ width: '100%', height: '100%' }}
        >
          <color attach="background" args={["#1a1a2e"]} />
          
          {/* Lighting setup */}
          <ambientLight intensity={0.6} />
          <directionalLight 
            position={[10, 10, 5]} 
            intensity={1} 
            castShadow
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
          />
          <pointLight position={[-10, -10, -5]} intensity={0.5} />

          <Suspense fallback={null}>
            <CubeScene />
          </Suspense>
        </Canvas>

        {/* Desktop Controls */}
        {!isMobile && (
          <SolverInterface />
        )}

        {/* Mobile Controls */}
        {isMobile && (
          <MobileControls />
        )}

        {/* Keyboard shortcuts help */}
        <div style={{
          position: 'absolute',
          top: '10px',
          left: '10px',
          color: 'white',
          background: 'rgba(0,0,0,0.7)',
          padding: '10px',
          borderRadius: '8px',
          fontSize: '0.8rem',
          maxWidth: '200px'
        }}>
          <div><strong>Controls:</strong></div>
          <div>F/R/U/L/D/B - Face moves</div>
          <div>Shift + Letter - Counter-clockwise</div>
          <div>Space - Scramble</div>
          <div>Enter - Solve</div>
          <div>Esc - Reset</div>
        </div>
      </KeyboardControls>
    </div>
  );
}

export default App;

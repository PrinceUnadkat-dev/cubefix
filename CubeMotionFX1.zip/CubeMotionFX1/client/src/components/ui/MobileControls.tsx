import { useState } from "react";
import { useCube } from "../../lib/stores/useCube";
import { useAudio } from "../../lib/stores/useAudio";
import { Button } from "./button";
import { Card, CardContent } from "./card";
import { Input } from "./input";
import { Badge } from "./badge";
import { 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Shuffle, 
  Play, 
  Square,
  ChevronUp,
  ChevronDown
} from "lucide-react";

export default function MobileControls() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [algorithmInput, setAlgorithmInput] = useState("");
  
  const {
    scramble,
    solve,
    reset,
    executeAlgorithm,
    executeMove,
    isAnimating,
    isSolved
  } = useCube();
  
  const { isMuted, toggleMute } = useAudio();

  const handleExecuteAlgorithm = () => {
    if (algorithmInput.trim()) {
      executeAlgorithm(algorithmInput.trim());
      setAlgorithmInput("");
    }
  };

  const faceButtons = [
    { label: "F", move: "F" },
    { label: "F'", move: "F'" },
    { label: "R", move: "R" },
    { label: "R'", move: "R'" },
    { label: "U", move: "U" },
    { label: "U'", move: "U'" },
    { label: "L", move: "L" },
    { label: "L'", move: "L'" },
    { label: "D", move: "D" },
    { label: "D'", move: "D'" },
    { label: "B", move: "B" },
    { label: "B'", move: "B'" },
  ];

  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 1000,
      transform: isExpanded ? 'translateY(0)' : 'translateY(calc(100% - 60px))',
      transition: 'transform 0.3s ease-in-out'
    }}>
      <Card className="bg-black/90 backdrop-blur-sm border-gray-700 rounded-t-lg rounded-b-none border-b-0">
        <CardContent className="p-4 space-y-3">
          {/* Toggle and Status Bar */}
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-white hover:bg-gray-700"
            >
              {isExpanded ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
              <span className="ml-2">Controls</span>
            </Button>
            
            <div className="flex items-center gap-2">
              <Badge variant={isSolved ? "default" : "secondary"} className="text-xs">
                {isSolved ? "Solved" : "Scrambled"}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMute}
                className="text-white hover:bg-gray-700"
              >
                {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </Button>
            </div>
          </div>

          {/* Expanded Controls */}
          {isExpanded && (
            <>
              {/* Main Action Buttons */}
              <div className="grid grid-cols-3 gap-2">
                <Button
                  onClick={scramble}
                  disabled={isAnimating}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  size="sm"
                >
                  <Shuffle size={14} className="mr-1" />
                  Scramble
                </Button>
                <Button
                  onClick={solve}
                  disabled={isAnimating || isSolved}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  <Play size={14} className="mr-1" />
                  Solve
                </Button>
                <Button
                  onClick={reset}
                  disabled={isAnimating}
                  className="bg-red-600 hover:bg-red-700 text-white"
                  size="sm"
                >
                  <RotateCcw size={14} className="mr-1" />
                  Reset
                </Button>
              </div>

              {/* Face Move Buttons */}
              <div className="grid grid-cols-6 gap-1">
                {faceButtons.map((btn) => (
                  <Button
                    key={btn.move}
                    onClick={() => executeMove(btn.move)}
                    disabled={isAnimating}
                    className="bg-gray-700 hover:bg-gray-600 text-white text-xs h-8"
                    size="sm"
                  >
                    {btn.label}
                  </Button>
                ))}
              </div>

              {/* Algorithm Input */}
              <div className="flex gap-1">
                <Input
                  placeholder="Algorithm (e.g., R U R' U')"
                  value={algorithmInput}
                  onChange={(e) => setAlgorithmInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleExecuteAlgorithm()}
                  className="bg-gray-800 border-gray-600 text-white text-sm"
                  disabled={isAnimating}
                />
                <Button
                  onClick={handleExecuteAlgorithm}
                  disabled={isAnimating || !algorithmInput.trim()}
                  size="sm"
                  className="bg-purple-600 hover:bg-purple-700 px-3"
                >
                  <Play size={14} />
                </Button>
              </div>

              {/* Animation Status */}
              {isAnimating && (
                <div className="text-center">
                  <div className="inline-flex items-center gap-2 text-yellow-400 text-sm">
                    <Square className="animate-spin" size={14} />
                    Animating...
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

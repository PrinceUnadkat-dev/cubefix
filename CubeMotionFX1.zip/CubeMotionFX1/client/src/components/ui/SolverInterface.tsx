import { useState } from "react";
import { useCube } from "../../lib/stores/useCube";
import { useAudio } from "../../lib/stores/useAudio";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Input } from "./input";
import { Badge } from "./badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./tabs";
import { Volume2, VolumeX, RotateCcw, Shuffle, Play, Square, Palette } from "lucide-react";
import ColorPicker from "./ColorPicker";

export default function SolverInterface() {
  const [algorithmInput, setAlgorithmInput] = useState("");
  const [showHelp, setShowHelp] = useState(false);
  
  const {
    scramble,
    solve,
    reset,
    executeAlgorithm,
    isAnimating,
    moveHistory,
    isSolved
  } = useCube();
  
  const { isMuted, toggleMute } = useAudio();

  const handleExecuteAlgorithm = () => {
    if (algorithmInput.trim()) {
      executeAlgorithm(algorithmInput.trim());
      setAlgorithmInput("");
    }
  };

  const commonAlgorithms = [
    { name: "Sexy Move", notation: "R U R' U'" },
    { name: "T-Perm", notation: "R U R' F' R U R' U' R' F R2 U' R'" },
    { name: "J-Perm", notation: "R U R' F' R U R' U' R' F R2 U' R'" },
    { name: "Y-Perm", notation: "F R U' R' U' R U R' F' R U R' U' R' F R F'" },
    { name: "Sune", notation: "R U R' U R U2 R'" },
    { name: "Anti-Sune", notation: "R U2 R' U' R U' R'" }
  ];

  return (
    <div style={{
      position: 'absolute',
      top: '20px',
      right: '20px',
      width: '320px',
      zIndex: 1000
    }}>
      <Card className="bg-black/80 backdrop-blur-sm border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg flex items-center justify-between">
            Cube Solver Pro
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMute}
                className="text-white hover:bg-gray-700"
              >
                {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </Button>
              <Badge variant={isSolved ? "default" : "secondary"}>
                {isSolved ? "Solved" : "Scrambled"}
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <Tabs defaultValue="controls" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="controls" className="text-xs">Controls</TabsTrigger>
              <TabsTrigger value="colors" className="text-xs">Colors</TabsTrigger>
              <TabsTrigger value="algorithms" className="text-xs">Algorithms</TabsTrigger>
              <TabsTrigger value="history" className="text-xs">History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="controls" className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={scramble}
                  disabled={isAnimating}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  size="sm"
                >
                  <Shuffle size={14} className="mr-1" />
                  Scramble
                </Button>
                <Button
                  onClick={solve}
                  disabled={isAnimating || isSolved}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  <Play size={14} className="mr-1" />
                  Solve
                </Button>
                <Button
                  onClick={reset}
                  disabled={isAnimating}
                  className="bg-red-600 hover:bg-red-700 text-white col-span-2"
                  size="sm"
                >
                  <RotateCcw size={14} className="mr-1" />
                  Reset
                </Button>
              </div>

              <div className="space-y-2">
                <div className="flex gap-1">
                  <Input
                    placeholder="Enter algorithm (e.g., R U R' U')"
                    value={algorithmInput}
                    onChange={(e) => setAlgorithmInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleExecuteAlgorithm()}
                    className="bg-gray-800 border-gray-600 text-white text-sm"
                    disabled={isAnimating}
                  />
                  <Button
                    onClick={handleExecuteAlgorithm}
                    disabled={isAnimating || !algorithmInput.trim()}
                    size="sm"
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Play size={14} />
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="colors" className="space-y-2">
              <ColorPicker />
            </TabsContent>
            
            <TabsContent value="algorithms" className="space-y-2">
              <div className="max-h-40 overflow-y-auto space-y-1">
                {commonAlgorithms.map((alg, index) => (
                  <div key={index} className="p-2 bg-gray-800 rounded text-xs">
                    <div className="text-white font-medium">{alg.name}</div>
                    <div className="text-gray-400 font-mono">{alg.notation}</div>
                    <Button
                      onClick={() => executeAlgorithm(alg.notation)}
                      disabled={isAnimating}
                      size="sm"
                      className="mt-1 text-xs h-6 bg-gray-700 hover:bg-gray-600"
                    >
                      Execute
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="history" className="space-y-2">
              <div className="max-h-40 overflow-y-auto">
                {moveHistory.length === 0 ? (
                  <div className="text-gray-400 text-sm text-center py-4">
                    No moves yet
                  </div>
                ) : (
                  <div className="space-y-1">
                    {moveHistory.slice(-10).map((move, index) => (
                      <div key={index} className="text-xs font-mono text-gray-300 bg-gray-800 p-1 rounded">
                        {move}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>

          {isAnimating && (
            <div className="text-center">
              <div className="inline-flex items-center gap-2 text-yellow-400 text-sm">
                <Square className="animate-spin" size={14} />
                Animating...
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

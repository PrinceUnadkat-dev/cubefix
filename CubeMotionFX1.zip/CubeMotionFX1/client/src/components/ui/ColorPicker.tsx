import { useColorManager, CUBE_COLORS, CubeColor } from "../../lib/stores/useColorManager";

interface ColorPickerProps {
  className?: string;
}

export default function ColorPicker({ className = "" }: ColorPickerProps) {
  const { 
    selectedColor, 
    isColoringMode, 
    colorCounts,
    setSelectedColor, 
    setColoringMode,
    resetColors,
    resetToSolved,
    canUseColor,
    getRemainingCount
  } = useColorManager();

  const colorEntries = Object.entries(CUBE_COLORS).filter(([key]) => key !== 'black') as [CubeColor, string][];

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Coloring Mode Toggle */}
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-foreground">
          Color Fill Mode
        </label>
        <button
          onClick={() => setColoringMode(!isColoringMode)}
          className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
            isColoringMode 
              ? 'bg-blue-500 text-white' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          {isColoringMode ? 'ON' : 'OFF'}
        </button>
      </div>

      {/* Color Palette */}
      {isColoringMode && (
        <div className="space-y-3">
          <div className="text-xs text-gray-600">
            Click a color to select, then click cube faces to fill
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            {colorEntries.map(([colorKey, colorValue]) => {
              const isSelected = selectedColor === colorKey;
              const canUse = canUseColor(colorKey);
              const remaining = getRemainingCount(colorKey);
              const used = colorCounts[colorKey];

              return (
                <button
                  key={colorKey}
                  onClick={() => setSelectedColor(colorKey)}
                  disabled={!canUse}
                  className={`
                    relative p-3 rounded-lg border-2 transition-all
                    ${isSelected ? 'border-blue-500 scale-105' : 'border-gray-300'}
                    ${canUse ? 'hover:scale-105' : 'opacity-50 cursor-not-allowed'}
                  `}
                  style={{ backgroundColor: colorValue }}
                  title={`${colorKey.charAt(0).toUpperCase() + colorKey.slice(1)} (${used}/9 used, ${remaining} remaining)`}
                >
                  {/* Color name */}
                  <div className={`
                    absolute -bottom-1 left-0 right-0 text-xs font-medium text-center
                    ${colorKey === 'white' || colorKey === 'yellow' ? 'text-gray-800' : 'text-white'}
                  `}>
                    {colorKey.charAt(0).toUpperCase()}
                  </div>
                  
                  {/* Counter */}
                  <div className={`
                    absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full text-xs font-bold
                    flex items-center justify-center border-2 border-white
                    ${remaining === 0 ? 'bg-red-500 text-white' : 'bg-green-500 text-white'}
                  `}>
                    {remaining}
                  </div>
                  
                  {/* Selection indicator */}
                  {isSelected && (
                    <div className="absolute inset-0 rounded-lg border-2 border-blue-500 bg-blue-500 bg-opacity-20"></div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Color count summary */}
          <div className="text-xs space-y-1">
            <div className="font-medium text-gray-700">Color Usage:</div>
            <div className="grid grid-cols-3 gap-1 text-xs">
              {colorEntries.map(([colorKey]) => (
                <div key={colorKey} className="flex justify-between">
                  <span className="capitalize">{colorKey}:</span>
                  <span className={colorCounts[colorKey] === 9 ? 'text-red-600 font-bold' : 'text-gray-600'}>
                    {colorCounts[colorKey]}/9
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Reset buttons */}
          <div className="flex gap-2">
            <button
              onClick={resetColors}
              className="flex-1 px-3 py-2 text-xs bg-gray-500 text-white rounded hover:bg-gray-600 transition-colors"
            >
              Clear All
            </button>
            <button
              onClick={resetToSolved}
              className="flex-1 px-3 py-2 text-xs bg-green-500 text-white rounded hover:bg-green-600 transition-colors"
            >
              Solved Colors
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
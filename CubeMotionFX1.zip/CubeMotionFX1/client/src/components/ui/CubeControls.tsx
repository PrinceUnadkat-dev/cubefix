import { useState } from "react";
import { useCube } from "../../lib/stores/useCube";
import { Button } from "./button";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Input } from "./input";
import { Badge } from "./badge";
import { Separator } from "./separator";
import { 
  Play, 
  Pause, 
  Square, 
  RotateCcw, 
  Shuffle,
  ChevronRight,
  ChevronLeft,
  FastForward
} from "lucide-react";

interface CubeControlsProps {
  className?: string;
}

export default function CubeControls({ className }: CubeControlsProps) {
  const [customAlgorithm, setCustomAlgorithm] = useState("");
  const [animationSpeed, setAnimationSpeed] = useState(1);
  
  const {
    executeMove,
    executeAlgorithm,
    scramble,
    solve,
    reset,
    isAnimating,
    isSolved,
    moveHistory,
    animationQueue
  } = useCube();

  const handleExecuteCustom = () => {
    if (customAlgorithm.trim() && !isAnimating) {
      executeAlgorithm(customAlgorithm.trim());
      setCustomAlgorithm("");
    }
  };

  const faceButtons = [
    { label: "F", moves: ["F", "F'", "F2"] },
    { label: "R", moves: ["R", "R'", "R2"] },
    { label: "U", moves: ["U", "U'", "U2"] },
    { label: "L", moves: ["L", "L'", "L2"] },
    { label: "D", moves: ["D", "D'", "D2"] },
    { label: "B", moves: ["B", "B'", "B2"] }
  ];

  const commonAlgorithms = [
    { name: "Sexy Move", notation: "R U R' U'", description: "Basic CFOP building block" },
    { name: "Sune", notation: "R U R' U R U2 R'", description: "OLL corner orientation" },
    { name: "Anti-Sune", notation: "R U2 R' U' R U' R'", description: "OLL corner orientation" },
    { name: "T-Perm", notation: "R U R' F' R U R' U' R' F R2 U' R'", description: "PLL edge permutation" },
    { name: "J-Perm", notation: "R U R' F' R U R' U' R' F R2 U' R'", description: "PLL corner permutation" }
  ];

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <span>Cube Controls</span>
          <div className="flex items-center gap-2">
            <Badge variant={isSolved ? "default" : "secondary"}>
              {isSolved ? "Solved" : "Scrambled"}
            </Badge>
            {isAnimating && (
              <Badge variant="outline" className="animate-pulse">
                <Square className="w-3 h-3 mr-1 animate-spin" />
                Animating
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Main Action Buttons */}
        <div className="grid grid-cols-3 gap-2">
          <Button
            onClick={scramble}
            disabled={isAnimating}
            className="bg-blue-600 hover:bg-blue-700"
            size="sm"
          >
            <Shuffle className="w-4 h-4 mr-1" />
            Scramble
          </Button>
          <Button
            onClick={solve}
            disabled={isAnimating || isSolved}
            className="bg-green-600 hover:bg-green-700"
            size="sm"
          >
            <Play className="w-4 h-4 mr-1" />
            Solve
          </Button>
          <Button
            onClick={reset}
            disabled={isAnimating}
            variant="outline"
            size="sm"
          >
            <RotateCcw className="w-4 h-4 mr-1" />
            Reset
          </Button>
        </div>

        <Separator />

        {/* Face Move Buttons */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Face Moves</h4>
          <div className="grid grid-cols-3 gap-2">
            {faceButtons.map((face) => (
              <div key={face.label} className="space-y-1">
                <div className="text-center text-xs font-medium text-muted-foreground">
                  {face.label}
                </div>
                <div className="grid grid-cols-3 gap-1">
                  {face.moves.map((move) => (
                    <Button
                      key={move}
                      onClick={() => executeMove(move)}
                      disabled={isAnimating}
                      variant="outline"
                      size="sm"
                      className="text-xs h-8"
                    >
                      {move}
                    </Button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Custom Algorithm Input */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Custom Algorithm</h4>
          <div className="flex gap-2">
            <Input
              placeholder="Enter moves (e.g., R U R' U')"
              value={customAlgorithm}
              onChange={(e) => setCustomAlgorithm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleExecuteCustom()}
              disabled={isAnimating}
              className="text-sm"
            />
            <Button
              onClick={handleExecuteCustom}
              disabled={isAnimating || !customAlgorithm.trim()}
              size="sm"
            >
              <Play className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Common Algorithms */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Common Algorithms</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {commonAlgorithms.map((alg, index) => (
              <div key={index} className="p-2 border rounded-lg space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{alg.name}</span>
                  <Button
                    onClick={() => executeAlgorithm(alg.notation)}
                    disabled={isAnimating}
                    size="sm"
                    variant="ghost"
                  >
                    <Play className="w-3 h-3" />
                  </Button>
                </div>
                <div className="text-xs text-muted-foreground">{alg.description}</div>
                <div className="text-xs font-mono bg-muted p-1 rounded">
                  {alg.notation}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Animation Queue Status */}
        {animationQueue.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Animation Queue</h4>
            <div className="text-xs text-muted-foreground">
              {animationQueue.length} moves remaining
            </div>
            <div className="flex gap-1 text-xs font-mono">
              {animationQueue.slice(0, 10).map((move, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {move.notation}
                </Badge>
              ))}
              {animationQueue.length > 10 && (
                <Badge variant="outline" className="text-xs">
                  +{animationQueue.length - 10}
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Move History */}
        {moveHistory.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Recent Moves</h4>
            <div className="text-xs font-mono bg-muted p-2 rounded max-h-20 overflow-y-auto">
              {moveHistory.slice(-5).map((move, index) => (
                <div key={index} className="truncate">
                  {move}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

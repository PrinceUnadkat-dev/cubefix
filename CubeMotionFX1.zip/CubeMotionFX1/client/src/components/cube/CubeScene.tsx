import { useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useRef } from "react";
import * as THREE from "three";
import RubiksCube from "./RubiksCube";
import { useCube } from "../../lib/stores/useCube";
import { useCubeControls } from "../../hooks/use-cube-controls";

export default function CubeScene() {
  const cubeRef = useRef<THREE.Group>(null);
  const { isAnimating } = useCube();
  
  // Handle keyboard controls
  useCubeControls();

  useFrame((state) => {
    // Gentle floating animation when not interacting
    if (cubeRef.current && !isAnimating) {
      cubeRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <>
      {/* Orbit controls for mouse interaction */}
      <OrbitControls 
        enablePan={false}
        enableZoom={true}
        enableRotate={true}
        minDistance={5}
        maxDistance={15}
        minPolarAngle={0}
        maxPolarAngle={Math.PI}
      />

      {/* Ground plane with shadow */}
      <mesh 
        receiveShadow 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, -3, 0]}
      >
        <planeGeometry args={[20, 20]} />
        <shadowMaterial transparent opacity={0.3} />
      </mesh>

      {/* Main cube group */}
      <group ref={cubeRef}>
        <RubiksCube />
      </group>

      {/* Additional lighting for better visibility */}
      <spotLight
        position={[5, 5, 5]}
        angle={0.6}
        penumbra={1}
        intensity={0.5}
        castShadow
      />
    </>
  );
}

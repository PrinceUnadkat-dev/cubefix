import * as THREE from "three";
import { CubeState } from "../../lib/cube/CubeState";
import { Move } from "../../lib/cube/MoveNotation";

interface PieceAnimation {
  mesh: THREE.Group;
  originalPosition: THREE.Vector3;
  startPosition: THREE.Vector3;
  targetPosition: THREE.Vector3;
  startRotation: THREE.Euler;
  targetRotation: THREE.Euler;
  isAnimating: boolean;
  animationProgress: number;
}

interface AnimationCallbacks {
  onAnimationStart: () => void;
  onAnimationComplete: () => void;
  onPieceUpdate: (pieceId: string, newPosition: THREE.Vector3, newRotation: THREE.Euler) => void;
}

export class AnimationManager {
  private pieces: Map<string, PieceAnimation> = new Map();
  private callbacks?: AnimationCallbacks;
  private isAnimating = false;
  private animatingPieces: Set<string> = new Set();
  private animationDuration = 0.5; // 500ms
  private animationStartTime = 0;

  setCallbacks(callbacks: AnimationCallbacks) {
    this.callbacks = callbacks;
  }

  registerPiece(id: string, mesh: THREE.Group, originalPosition: THREE.Vector3) {
    console.log(`Registering piece: ${id} at position:`, originalPosition);
    this.pieces.set(id, {
      mesh,
      originalPosition: originalPosition.clone(),
      startPosition: mesh.position.clone(),
      targetPosition: mesh.position.clone(),
      startRotation: mesh.rotation.clone(),
      targetRotation: mesh.rotation.clone(),
      isAnimating: false,
      animationProgress: 0
    });
    console.log(`Total registered pieces: ${this.pieces.size}`);
  }

  executeMove(move: Move, cubeState: CubeState) {
    if (this.isAnimating) {
      console.warn("Animation already in progress, skipping move");
      return;
    }

    console.log(`Executing move: ${move.notation}`);
    console.log(`Registered pieces count: ${this.pieces.size}`);
    
    this.isAnimating = true;
    this.animationStartTime = performance.now();
    this.callbacks?.onAnimationStart();

    // Get affected pieces for this move - exactly 8 pieces per layer
    const affectedPieces = this.getAffectedPieces(move);
    console.log(`Affected pieces: ${affectedPieces.length}`, affectedPieces);

    if (affectedPieces.length !== 8) {
      console.error(`Expected 8 pieces for move ${move.notation}, got ${affectedPieces.length}`);
      this.completeAnimation();
      return;
    }

    // Check how many pieces are actually registered
    const availablePieces = affectedPieces.filter(id => this.pieces.has(id));
    console.log(`Available pieces: ${availablePieces.length}/${affectedPieces.length}`);
    if (availablePieces.length === 0) {
      console.error("No pieces available for animation!");
      this.completeAnimation();
      return;
    }

    this.animatingPieces.clear();

    // Calculate and set new positions for each piece
    affectedPieces.forEach(pieceId => {
      const piece = this.pieces.get(pieceId);
      if (!piece) {
        console.warn(`Piece ${pieceId} not found in animation manager`);
        return;
      }

      this.animatingPieces.add(pieceId);

      // Store starting position and rotation
      piece.startPosition.copy(piece.mesh.position);
      piece.startRotation.copy(piece.mesh.rotation);
      piece.isAnimating = true;
      piece.animationProgress = 0;

      // Calculate new target position and rotation
      const { newPosition, newRotation } = this.calculateNewTransform(pieceId, move);
      piece.targetPosition.copy(newPosition);
      piece.targetRotation.copy(newRotation);
    });
  }

  private getAffectedPieces(move: Move): string[] {
    const affected: string[] = [];
    
    // Define which pieces are affected by each face move
    // Each face move affects exactly 8 pieces (corners and edges of that face)
    switch (move.face.toLowerCase()) {
      case 'f': // Front face (z = 2)
        // 4 corners + 4 edges = 8 pieces
        affected.push('0-0-2', '2-0-2', '0-2-2', '2-2-2'); // corners
        affected.push('1-0-2', '0-1-2', '2-1-2', '1-2-2'); // edges
        break;
      case 'b': // Back face (z = 0)
        affected.push('0-0-0', '2-0-0', '0-2-0', '2-2-0'); // corners
        affected.push('1-0-0', '0-1-0', '2-1-0', '1-2-0'); // edges
        break;
      case 'r': // Right face (x = 2)
        affected.push('2-0-0', '2-0-2', '2-2-0', '2-2-2'); // corners
        affected.push('2-0-1', '2-1-0', '2-1-2', '2-2-1'); // edges
        break;
      case 'l': // Left face (x = 0)
        affected.push('0-0-0', '0-0-2', '0-2-0', '0-2-2'); // corners
        affected.push('0-0-1', '0-1-0', '0-1-2', '0-2-1'); // edges
        break;
      case 'u': // Up face (y = 2)
        affected.push('0-2-0', '0-2-2', '2-2-0', '2-2-2'); // corners
        affected.push('0-2-1', '1-2-0', '1-2-2', '2-2-1'); // edges
        break;
      case 'd': // Down face (y = 0)
        affected.push('0-0-0', '0-0-2', '2-0-0', '2-0-2'); // corners
        affected.push('0-0-1', '1-0-0', '1-0-2', '2-0-1'); // edges
        break;
      default:
        console.error(`Unknown face: ${move.face}`);
    }

    return affected;
  }

  private calculateNewTransform(pieceId: string, move: Move): { newPosition: THREE.Vector3, newRotation: THREE.Euler } {
    const [x, y, z] = pieceId.split('-').map(Number);
    const currentPos = new THREE.Vector3(
      (x - 1) * 1.0,
      (y - 1) * 1.0,
      (z - 1) * 1.0
    );

    // Calculate rotation angle
    const angle = move.direction * (move.amount * Math.PI / 2);
    
    let rotationAxis: THREE.Vector3;
    let rotationCenter: THREE.Vector3;
    let newRotation = new THREE.Euler(0, 0, 0);

    // Define rotation axis and center for each face
    switch (move.face.toLowerCase()) {
      case 'f': // Front face rotates around Z axis
        rotationAxis = new THREE.Vector3(0, 0, 1);
        rotationCenter = new THREE.Vector3(0, 0, 1);
        newRotation.z = angle;
        break;
      case 'b': // Back face rotates around -Z axis  
        rotationAxis = new THREE.Vector3(0, 0, -1);
        rotationCenter = new THREE.Vector3(0, 0, -1);
        newRotation.z = -angle;
        break;
      case 'r': // Right face rotates around X axis
        rotationAxis = new THREE.Vector3(1, 0, 0);
        rotationCenter = new THREE.Vector3(1, 0, 0);
        newRotation.x = angle;
        break;
      case 'l': // Left face rotates around -X axis
        rotationAxis = new THREE.Vector3(-1, 0, 0);
        rotationCenter = new THREE.Vector3(-1, 0, 0);
        newRotation.x = -angle;
        break;
      case 'u': // Up face rotates around Y axis
        rotationAxis = new THREE.Vector3(0, 1, 0);
        rotationCenter = new THREE.Vector3(0, 1, 0);
        newRotation.y = angle;
        break;
      case 'd': // Down face rotates around -Y axis
        rotationAxis = new THREE.Vector3(0, -1, 0);
        rotationCenter = new THREE.Vector3(0, -1, 0);
        newRotation.y = -angle;
        break;
      default:
        rotationAxis = new THREE.Vector3(0, 1, 0);
        rotationCenter = new THREE.Vector3(0, 0, 0);
    }

    // Calculate new position by rotating around the face center
    const relativePos = currentPos.clone().sub(rotationCenter);
    const rotationMatrix = new THREE.Matrix4().makeRotationAxis(rotationAxis, angle);
    const newPosition = relativePos.applyMatrix4(rotationMatrix).add(rotationCenter);

    return { newPosition, newRotation };
  }

  update(delta: number): void {
    if (!this.isAnimating || this.animatingPieces.size === 0) return;

    const elapsed = (performance.now() - this.animationStartTime) / 1000;
    const progress = Math.min(elapsed / this.animationDuration, 1);

    // Use easing function for smoother animation
    const easedProgress = this.easeInOutCubic(progress);

    let allAnimationsComplete = true;

    this.animatingPieces.forEach(pieceId => {
      const piece = this.pieces.get(pieceId);
      if (!piece || !piece.isAnimating) return;

      piece.animationProgress = easedProgress;

      // Interpolate position
      piece.mesh.position.lerpVectors(piece.startPosition, piece.targetPosition, easedProgress);
      
      // Interpolate rotation
      const startQuat = new THREE.Quaternion().setFromEuler(piece.startRotation);
      const targetQuat = new THREE.Quaternion().setFromEuler(piece.targetRotation);
      const currentQuat = new THREE.Quaternion().slerpQuaternions(startQuat, targetQuat, easedProgress);
      piece.mesh.rotation.setFromQuaternion(currentQuat);

      if (progress < 1) {
        allAnimationsComplete = false;
      } else {
        // Animation complete for this piece
        piece.mesh.position.copy(piece.targetPosition);
        piece.mesh.rotation.copy(piece.targetRotation);
        piece.isAnimating = false;
        piece.animationProgress = 1;
      }
    });

    if (allAnimationsComplete) {
      this.completeAnimation();
    }
  }

  private easeInOutCubic(t: number): number {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }

  private completeAnimation(): void {
    console.log("Animation complete");
    
    // Update piece positions in the cube state
    this.animatingPieces.forEach(pieceId => {
      const piece = this.pieces.get(pieceId);
      if (piece) {
        this.callbacks?.onPieceUpdate(pieceId, piece.mesh.position, piece.mesh.rotation);
      }
    });

    this.isAnimating = false;
    this.animatingPieces.clear();
    this.callbacks?.onAnimationComplete();
  }

  isCurrentlyAnimating(): boolean {
    return this.isAnimating;
  }

  // Get animation progress for debugging
  getAnimationProgress(): number {
    if (!this.isAnimating) return 1;
    return Math.min((performance.now() - this.animationStartTime) / (this.animationDuration * 1000), 1);
  }

  // Force stop all animations
  stopAllAnimations(): void {
    this.animatingPieces.forEach(pieceId => {
      const piece = this.pieces.get(pieceId);
      if (piece) {
        piece.isAnimating = false;
        piece.mesh.position.copy(piece.targetPosition);
        piece.mesh.rotation.copy(piece.targetRotation);
      }
    });
    
    this.completeAnimation();
  }
}

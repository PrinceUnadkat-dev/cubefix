import { useRef, useEffect, forwardRef, useImperativeHandle } from "react";
import * as THREE from "three";
import { useColorManager, CUBE_COLORS } from "../../lib/stores/useColorManager";

interface CubePieceProps {
  id: string;
  position: THREE.Vector3;
  size: number;
  colors: Record<string, string>;
  onRegister: (id: string, mesh: THREE.Group, position: THREE.Vector3) => void;
}

// Standard Rubik's cube colors
const FACE_COLORS = {
  front: '#009E4F',   // Green
  back: '#0052CC',    // Blue  
  right: '#FF6900',   // Orange
  left: '#CC0000',    // Red
  up: '#FFFF00',      // Yellow
  down: '#FFFFFF'     // White
};

const FACE_POSITIONS = {
  front: [0, 0, 0.5],
  back: [0, 0, -0.5],
  right: [0.5, 0, 0],
  left: [-0.5, 0, 0],
  up: [0, 0.5, 0],
  down: [0, -0.5, 0]
};

const FACE_ROTATIONS = {
  front: [0, 0, 0],
  back: [0, Math.PI, 0],
  right: [0, Math.PI / 2, 0],
  left: [0, -Math.PI / 2, 0],
  up: [-Math.PI / 2, 0, 0],
  down: [Math.PI / 2, 0, 0]
};

export interface CubePieceRef {
  getMesh: () => THREE.Group | null;
  getPosition: () => THREE.Vector3;
  setPosition: (position: THREE.Vector3) => void;
  setRotation: (rotation: THREE.Euler) => void;
}

const CubePiece = forwardRef<CubePieceRef, CubePieceProps>(({ 
  id, 
  position, 
  size, 
  colors, 
  onRegister 
}, ref) => {
  const meshRef = useRef<THREE.Group>(null);
  const { 
    isColoringMode, 
    selectedColor, 
    filledStickers, 
    fillSticker,
    canUseColor 
  } = useColorManager();

  // Expose methods to parent components
  useImperativeHandle(ref, () => ({
    getMesh: () => meshRef.current,
    getPosition: () => meshRef.current?.position || new THREE.Vector3(),
    setPosition: (newPosition: THREE.Vector3) => {
      if (meshRef.current) {
        meshRef.current.position.copy(newPosition);
      }
    },
    setRotation: (newRotation: THREE.Euler) => {
      if (meshRef.current) {
        meshRef.current.rotation.copy(newRotation);
      }
    }
  }));

  // Register with animation manager on mount
  useEffect(() => {
    if (meshRef.current) {
      onRegister(id, meshRef.current, position);
    }
  }, [id, onRegister, position]);

  // Handle face click for color filling
  const handleFaceClick = (faceName: string) => {
    if (isColoringMode && canUseColor(selectedColor)) {
      fillSticker(id, faceName, selectedColor);
    }
  };

  // Create face geometries with proper collision boundaries
  const faces = Object.entries(FACE_POSITIONS).map(([faceName, facePosition]) => {
    // Get color from either filled stickers or default colors
    const stickerId = `${id}-${faceName}`;
    const filledColor = filledStickers[stickerId];
    const finalColor = filledColor 
      ? CUBE_COLORS[filledColor]
      : (colors[faceName] || FACE_COLORS[faceName as keyof typeof FACE_COLORS] || '#333333');
    
    const rotation = FACE_ROTATIONS[faceName as keyof typeof FACE_ROTATIONS];
    
    return (
      <group key={faceName}>
        {/* Colored face */}
        <mesh
          position={facePosition as [number, number, number]}
          rotation={rotation as [number, number, number]}
          castShadow
          receiveShadow
          onClick={() => handleFaceClick(faceName)}
          onPointerOver={(e) => {
            if (isColoringMode) {
              e.stopPropagation();
              document.body.style.cursor = 'pointer';
            }
          }}
          onPointerOut={() => {
            document.body.style.cursor = 'default';
          }}
        >
          <planeGeometry args={[size * 0.9, size * 0.9]} />
          <meshPhongMaterial 
            color={finalColor}
            shininess={100}
            specular={0x222222}
            transparent={isColoringMode}
            opacity={isColoringMode ? 0.9 : 1}
          />
        </mesh>
        
        {/* Black border */}
        <mesh 
          position={[
            facePosition[0], 
            facePosition[1], 
            facePosition[2] - 0.001
          ]}
          rotation={rotation as [number, number, number]}
        >
          <planeGeometry args={[size, size]} />
          <meshBasicMaterial color="#000000" />
        </mesh>
      </group>
    );
  });

  return (
    <group 
      ref={meshRef} 
      position={position}
      castShadow
      receiveShadow
      userData={{ pieceId: id, type: 'cubePiece' }}
    >
      {/* Main cube body with collision bounds */}
      <mesh castShadow receiveShadow>
        <boxGeometry args={[size, size, size]} />
        <meshPhongMaterial 
          color="#222222"
          transparent
          opacity={0.1} // Semi-transparent to see faces better
        />
      </mesh>
      
      {/* Colored faces */}
      {faces}

      {/* Invisible collision box for precise collision detection */}
      <mesh visible={false}>
        <boxGeometry args={[size + 0.01, size + 0.01, size + 0.01]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
    </group>
  );
});

CubePiece.displayName = 'CubePiece';

export default CubePiece;

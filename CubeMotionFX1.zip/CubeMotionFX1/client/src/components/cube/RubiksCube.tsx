import { useEffect, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import CubePiece from "./CubePiece";
import { useCube } from "../../lib/stores/useCube";
import { AnimationManager } from "./AnimationManager";

const CUBE_SIZE = 3;
const PIECE_SIZE = 0.95;
const PIECE_GAP = 0.05;

export default function RubiksCube() {
  const groupRef = useRef<THREE.Group>(null);
  const animationManager = useRef(new AnimationManager());
  
  const { 
    cubeState, 
    isAnimating, 
    currentMove,
    setAnimating,
    updatePiecePosition,
    animationQueue
  } = useCube();

  // Initialize animation manager
  useEffect(() => {
    if (animationManager.current) {
      animationManager.current.setCallbacks({
        onAnimationStart: () => setAnimating(true),
        onAnimationComplete: () => setAnimating(false),
        onPieceUpdate: updatePiecePosition
      });
    }
  }, [setAnimating, updatePiecePosition]);

  // Process animation queue
  useEffect(() => {
    if (currentMove && !isAnimating && animationManager.current) {
      console.log(`Starting animation for move: ${currentMove.notation}`);
      animationManager.current.executeMove(currentMove, cubeState);
    }
  }, [currentMove, isAnimating, cubeState]);

  useFrame((state, delta) => {
    if (animationManager.current) {
      animationManager.current.update(delta);
    }
  });

  // Handle piece registration with animation manager
  const handlePieceRegister = (id: string, mesh: THREE.Group, position: THREE.Vector3) => {
    if (animationManager.current) {
      animationManager.current.registerPiece(id, mesh, position);
    }
  };

  // Generate cube pieces
  const pieces = [];
  for (let x = 0; x < CUBE_SIZE; x++) {
    for (let y = 0; y < CUBE_SIZE; y++) {
      for (let z = 0; z < CUBE_SIZE; z++) {
        // Skip the center piece (invisible)
        if (x === 1 && y === 1 && z === 1) continue;

        const position = new THREE.Vector3(
          (x - 1) * (PIECE_SIZE + PIECE_GAP),
          (y - 1) * (PIECE_SIZE + PIECE_GAP),
          (z - 1) * (PIECE_SIZE + PIECE_GAP)
        );

        const pieceId = `${x}-${y}-${z}`;
        const pieceState = cubeState.pieces[pieceId];

        pieces.push(
          <CubePiece
            key={pieceId}
            id={pieceId}
            position={position}
            size={PIECE_SIZE}
            colors={pieceState?.colors || {}}
            onRegister={handlePieceRegister}
          />
        );
      }
    }
  }

  return (
    <group ref={groupRef} castShadow receiveShadow>
      {pieces}
    </group>
  );
}

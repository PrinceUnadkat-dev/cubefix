# Overview

CubeSolverPro is an interactive 3D Rubik's Cube application built with React, Three.js, and TypeScript. The application provides a realistic 3D cube interface with advanced solving capabilities, animation systems, and both desktop and mobile controls. Users can scramble, solve, and manipulate the cube using keyboard controls, touch gestures, or on-screen buttons.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The application follows a modern React architecture with TypeScript, utilizing React Three Fiber for 3D rendering and Zustand for state management.

**Component Structure:**
- **App.tsx**: Main application wrapper with keyboard controls and canvas setup
- **CubeScene.tsx**: Three.js scene container with camera controls and lighting
- **RubiksCube.tsx**: Main cube component managing 26 individual pieces
- **CubePiece.tsx**: Individual cube piece with face colors and positioning
- **AnimationManager.tsx**: Handles complex move animations and transitions

**State Management:**
- **useCube**: Central cube state including piece positions, move history, and animation queue
- **useAudio**: Audio system state for sound effects and background music
- Zustand with subscribeWithSelector middleware for reactive state updates

**Styling:**
- Tailwind CSS for UI components with custom design system
- Radix UI components for accessible interface elements
- Custom CSS for 3D canvas and full-screen layout

## Backend Architecture

The backend uses a minimal Express.js setup designed for potential expansion:

**Server Structure:**
- **index.ts**: Express server with middleware and error handling
- **routes.ts**: API route definitions (currently placeholder)
- **storage.ts**: Storage interface with in-memory implementation
- **vite.ts**: Development server integration with HMR support

**Data Layer:**
- Drizzle ORM configured for PostgreSQL
- Schema definitions in shared directory for type safety
- Memory storage implementation for development

## 3D Graphics System

**Three.js Integration:**
- React Three Fiber for declarative 3D scene management
- Custom cube geometry with individual piece tracking
- Advanced animation system with collision detection
- OrbitControls for intuitive camera manipulation

**Animation Framework:**
- Queue-based move execution preventing conflicts
- Smooth interpolation between cube states
- Priority-based animation scheduling
- Performance-optimized rendering with frame-based updates

## Cube Logic System

**Move Notation:**
- Standard Rubik's cube notation (F, R, U, L, D, B with modifiers)
- Algorithm parsing for complex move sequences
- Move validation and inverse calculation

**Solving Algorithms:**
- CFOP method implementation with step-by-step guidance
- Scramble generation using random move sequences
- Basic solving demonstration (placeholder for advanced algorithms)

**State Management:**
- 26-piece cube state tracking
- Position and rotation matrices for each piece
- Solved state detection and validation

# External Dependencies

## 3D Graphics and Animation
- **three**: Core 3D graphics library
- **@react-three/fiber**: React renderer for Three.js
- **@react-three/drei**: Utility components for common 3D patterns
- **@react-three/postprocessing**: Post-processing effects

## UI Framework
- **@radix-ui/***: Complete set of accessible UI primitives
- **lucide-react**: Icon library for interface elements
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant handling

## State and Data Management
- **zustand**: Lightweight state management
- **@tanstack/react-query**: Server state synchronization
- **drizzle-orm**: Type-safe database ORM
- **@neondatabase/serverless**: Serverless PostgreSQL driver

## Development Tools
- **vite**: Fast build tool with HMR support
- **typescript**: Type safety and developer experience
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **vite-plugin-glsl**: GLSL shader support

## Backend Infrastructure
- **express**: Web application framework
- **drizzle-kit**: Database migration toolkit
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling

The architecture prioritizes performance, type safety, and modularity while providing a rich interactive experience for Rubik's cube enthusiasts.